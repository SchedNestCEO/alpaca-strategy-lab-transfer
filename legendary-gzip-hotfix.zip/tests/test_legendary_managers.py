from __future__ import annotations

from datetime import date, datetime, timezone
from decimal import Decimal
from types import SimpleNamespace

import pandas as pd
import pytest

from bot.backtest import BacktestSettings
from bot.legendary_managers import (
    ManagerDisclosureSignal,
    _Filing,
    _Holding,
    build_legendary_manager_signals,
    load_manager_signals_csv,
    manager_consensus_count_at,
)
from bot.strategies.legendary import (
    LEGENDARY_13F_CONCENTRATED,
    LEGENDARY_13F_CONSENSUS,
    LEGENDARY_13F_GREEN,
    LEGENDARY_13F_RAW,
    evaluate_legendary_signal,
)
from bot.strategy_lab import LegendaryManagerSimulator

UTC = timezone.utc


def _bars(periods: int = 300) -> pd.DataFrame:
    dates = list(pd.bdate_range("2024-01-02", periods=periods).date)
    closes = [100 * (1.0005 ** i) for i in range(periods)]
    return pd.DataFrame(
        {
            "open": closes,
            "high": [v * 1.01 for v in closes],
            "low": [v * 0.99 for v in closes],
            "close": closes,
            "volume": [1_000_000.0] * periods,
        },
        index=dates,
    )


def _settings(frame: pd.DataFrame) -> BacktestSettings:
    return BacktestSettings(
        start=frame.index[230],
        end=frame.index[270],
        initial_capital=Decimal("100"),
        watchlist=("AAA",),
        trend_fast_sma=50,
        trend_slow_sma=200,
        max_daily_drawdown_pct=Decimal("1"),
        max_high_water_drawdown_pct=Decimal("0.05"),
        slippage=Decimal("0"),
    )


def _green(history, fast, slow):
    del history, fast, slow
    return SimpleNamespace(regime="GREEN", score=100.0)


def _signal(manager: str, filing_day: date, *, weight: float = 0.03, side: str = "BUY") -> ManagerDisclosureSignal:
    return ManagerDisclosureSignal(
        manager_id=manager,
        manager_label=manager,
        symbol="AAA",
        side=side,
        report_period=date(2024, 12, 31),
        filing_time=datetime.combine(filing_day, datetime.min.time(), tzinfo=UTC),
        shares=Decimal("200") if side == "BUY" else Decimal("100"),
        prior_shares=Decimal("100") if side == "BUY" else Decimal("200"),
        change_pct=1.0 if side == "BUY" else -0.5,
        portfolio_weight=weight,
        source_accession=f"{manager}-{side}-{filing_day}",
        verified=True,
    )


def test_legendary_loader_requires_timezone_and_strict_schema(tmp_path):
    path = tmp_path / "legend.csv"
    path.write_text(
        "manager_id,manager_label,symbol,side,report_period,filing_time,shares,prior_shares,change_pct,portfolio_weight,source_accession,verified\n"
        "m,Manager,AAA,BUY,2024-12-31,2025-02-14T20:00:00,200,100,1,0.05,x,true\n"
    )
    with pytest.raises(ValueError, match="timezone-aware"):
        load_manager_signals_csv(path)


def test_consensus_counts_only_public_filings_at_candidate_time():
    first = _signal("m1", date(2025, 2, 14))
    second = _signal("m2", date(2025, 2, 15))
    assert manager_consensus_count_at(first, [first, second]) == 1
    assert manager_consensus_count_at(second, [first, second]) == 2


def test_legendary_policy_variants_use_fixed_public_filters():
    frame = _bars()
    settings = _settings(frame)
    history = frame.loc[: settings.start].copy()
    from bot.strategies.common import indicators

    history = indicators(history)
    candidate = _signal("m1", settings.start, weight=0.03)
    peer = _signal("m2", settings.start, weight=0.03)
    assert evaluate_legendary_signal(
        LEGENDARY_13F_RAW, candidate, all_signals=[candidate], history=history, regime="YELLOW", settings=settings
    ).accepted
    assert evaluate_legendary_signal(
        LEGENDARY_13F_CONCENTRATED,
        candidate,
        all_signals=[candidate],
        history=history,
        regime="GREEN",
        settings=settings,
    ).accepted
    assert evaluate_legendary_signal(
        LEGENDARY_13F_CONSENSUS,
        peer,
        all_signals=[candidate, peer],
        history=history,
        regime="GREEN",
        settings=settings,
    ).accepted
    assert not evaluate_legendary_signal(
        LEGENDARY_13F_GREEN,
        candidate,
        all_signals=[candidate],
        history=history,
        regime="YELLOW",
        settings=settings,
    ).accepted


def test_legendary_simulator_enters_after_filing_and_exits_after_reduction():
    frame = _bars()
    settings = _settings(frame)
    filing_day = settings.start
    sell_day = frame.index[240]
    signals = [_signal("m1", filing_day), _signal("m1", sell_day, side="SELL")]
    result = LegendaryManagerSimulator(
        LEGENDARY_13F_RAW,
        settings,
        {"AAA": frame, "SPY": frame},
        signals,
        regime_fn=_green,
    ).run()
    assert result.trades
    trade = result.trades[0]
    assert date.fromisoformat(trade["entry_date"]) > filing_day
    assert trade["exit_reason"] == "manager_disclosed_reduction"
    assert trade["manager_id"] == "m1"


def test_builder_differences_13f_holdings_without_inventing_trade_time(tmp_path, monkeypatch):
    import bot.legendary_managers as lm

    filings = [
        _Filing("m1", "Manager One", "0000000001", "a1", date(2024, 9, 30), datetime(2024, 11, 14, 21, tzinfo=UTC)),
        _Filing("m1", "Manager One", "0000000001", "a2", date(2024, 12, 31), datetime(2025, 2, 14, 21, tzinfo=UTC)),
    ]
    holdings = {
        "a1": [_Holding("111111111", "AAA Inc", Decimal("100"), Decimal("1000"))],
        "a2": [_Holding("111111111", "AAA Inc", Decimal("200"), Decimal("3000"))],
    }
    monkeypatch.setattr(lm, "_manager_filings", lambda manager, start, end, user_agent: filings)
    monkeypatch.setattr(lm, "_filing_holdings", lambda filing, user_agent: holdings[filing.accession])
    monkeypatch.setattr(lm, "_openfigi_map", lambda cusips, api_key, user_agent: {"111111111": "AAA"})
    monkeypatch.setattr(lm.time, "sleep", lambda _: None)

    out = tmp_path / "legendary.csv"
    result = build_legendary_manager_signals(
        start=date(2025, 1, 1),
        end=date(2025, 3, 31),
        output_path=out,
        sec_user_agent="Research Bot test@example.com",
        min_portfolio_weight=0.0,
        managers=({"manager_id": "m1", "manager_label": "Manager One", "cik": "0000000001"},),
    )
    assert len(result) == 1
    assert result[0].side == "BUY"
    assert result[0].filing_time == filings[1].filing_time
    assert result[0].report_period == date(2024, 12, 31)
    assert out.exists()


def test_request_decompresses_gzip_response(monkeypatch):
    import gzip
    import bot.legendary_managers as lm

    payload = b'{"ok": true}'

    class _Headers:
        def get(self, key, default=None):
            return "gzip" if key == "Content-Encoding" else default

    class _Response:
        headers = _Headers()

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def read(self):
            return gzip.compress(payload)

    monkeypatch.setattr(lm.urllib.request, "urlopen", lambda request, timeout=30: _Response())
    assert lm._request("https://example.test/data", user_agent="Research Bot test@example.com") == payload
