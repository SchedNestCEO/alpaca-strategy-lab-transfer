from __future__ import annotations

import csv
import json
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable

DIVIDEND_REQUIRED_COLUMNS = ("symbol", "ex_date", "payable_date", "rate")
DIVIDEND_OPTIONAL_COLUMNS = ("source_id", "verified")
DIVIDEND_ALLOWED_COLUMNS = frozenset((*DIVIDEND_REQUIRED_COLUMNS, *DIVIDEND_OPTIONAL_COLUMNS))


@dataclass(frozen=True)
class CashDividend:
    symbol: str
    ex_date: date
    payable_date: date
    rate: Decimal
    source_id: str | None = None
    verified: bool = True


def _normalize_symbol(raw: str) -> str:
    symbol = raw.strip().upper()
    if not symbol or not symbol.replace(".", "").replace("-", "").isalnum():
        raise ValueError(f"invalid dividend symbol {raw!r}")
    return symbol


def _parse_bool(raw: str) -> bool:
    value = raw.strip().lower()
    if value in {"1", "true", "yes", "y"}:
        return True
    if value in {"0", "false", "no", "n"}:
        return False
    raise ValueError("verified must be true/false")


def load_dividend_events_csv(path: str | Path) -> list[CashDividend]:
    source = Path(path)
    if not source.exists() or not source.is_file():
        raise ValueError(f"dividend-events CSV does not exist: {source}")
    out: list[CashDividend] = []
    seen: set[tuple[str, date, date, Decimal]] = set()
    with source.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = tuple(reader.fieldnames or ())
        missing = [x for x in DIVIDEND_REQUIRED_COLUMNS if x not in fields]
        unknown = [x for x in fields if x not in DIVIDEND_ALLOWED_COLUMNS]
        if missing:
            raise ValueError(f"dividend-events CSV missing required columns: {', '.join(missing)}")
        if unknown:
            raise ValueError(f"dividend-events CSV has unknown columns: {', '.join(unknown)}")
        for row_number, row in enumerate(reader, start=2):
            try:
                symbol = _normalize_symbol(row["symbol"])
                ex_date = date.fromisoformat((row["ex_date"] or "").strip())
                payable_date = date.fromisoformat((row["payable_date"] or "").strip())
                rate = Decimal((row["rate"] or "").strip())
            except (ValueError, InvalidOperation) as exc:
                raise ValueError(f"row {row_number}: invalid dividend event") from exc
            if rate <= 0 or not rate.is_finite():
                raise ValueError(f"row {row_number}: dividend rate must be positive")
            if payable_date < ex_date:
                raise ValueError(f"row {row_number}: payable_date cannot precede ex_date")
            verified_raw = (row.get("verified") or "true").strip()
            verified = _parse_bool(verified_raw) if verified_raw else True
            source_id = (row.get("source_id") or "").strip() or None
            key = (symbol, ex_date, payable_date, rate)
            if key in seen:
                continue
            seen.add(key)
            out.append(CashDividend(symbol, ex_date, payable_date, rate, source_id, verified))
    out.sort(key=lambda x: (x.ex_date, x.symbol, x.payable_date, x.rate))
    return out


def dividend_symbols(events: Iterable[CashDividend]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(event.symbol for event in events if event.verified))


def trailing_dividend_stats(
    events: Iterable[CashDividend], *, symbol: str, as_of: date, price: Decimal, lookback_days: int = 400
) -> dict[str, float | bool]:
    if price <= 0:
        return {"yield": 0.0, "payments": 0, "stable": False, "cut": False}
    start = as_of - timedelta(days=lookback_days)
    history = sorted(
        [e for e in events if e.verified and e.symbol == symbol and start <= e.ex_date <= as_of],
        key=lambda e: e.ex_date,
    )
    ttm_start = as_of - timedelta(days=365)
    ttm = [e for e in history if e.ex_date > ttm_start]
    total = sum((e.rate for e in ttm), Decimal("0"))
    rates = [e.rate for e in history]
    cut = False
    if len(rates) >= 4:
        prior = sorted(rates[-4:-1])
        median = prior[len(prior) // 2]
        cut = rates[-1] < median * Decimal("0.75")
    stable = len(ttm) >= 3 and not cut
    return {
        "yield": float(total / price),
        "payments": len(ttm),
        "stable": stable,
        "cut": cut,
    }


def _http_json(url: str, *, api_key: str, secret_key: str, retries: int = 4) -> dict:
    headers = {"APCA-API-KEY-ID": api_key, "APCA-API-SECRET-KEY": secret_key, "Accept": "application/json"}
    for attempt in range(retries + 1):
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code == 429 and attempt < retries:
                retry_after = float(exc.headers.get("Retry-After", "2") or 2)
                time.sleep(max(1.0, retry_after))
                continue
            raise RuntimeError(f"HTTP {exc.code} from Alpaca corporate actions") from exc
        except urllib.error.URLError as exc:
            if attempt < retries:
                time.sleep(1.5 * (attempt + 1))
                continue
            raise RuntimeError(f"Network error fetching Alpaca corporate actions: {exc.reason}") from exc
    raise RuntimeError("Alpaca corporate-actions request failed")


def _extract_cash_dividends(payload: dict) -> list[dict]:
    """Extract cash-dividend records from Alpaca's response without assuming one nesting shape.

    Alpaca's corporate-actions endpoint has evolved over time and SDK/API versions may
    return type buckets either as lists or symbol-keyed mappings. We therefore walk the
    payload recursively and collect dicts that look like cash-dividend records.
    """
    found: list[dict] = []

    def walk(value: object, *, in_cash_bucket: bool = False) -> None:
        if isinstance(value, list):
            for item in value:
                walk(item, in_cash_bucket=in_cash_bucket)
            return
        if not isinstance(value, dict):
            return

        type_text = str(value.get("type") or value.get("ca_type") or value.get("corporate_action_type") or "").lower()
        subtype_text = str(value.get("sub_type") or value.get("ca_sub_type") or "").lower()
        has_dates = bool(value.get("ex_date") or value.get("exDate"))
        has_rate = any(value.get(k) not in (None, "") for k in ("rate", "cash", "amount"))
        looks_cash = in_cash_bucket or "cash_dividend" in type_text or ("dividend" in type_text and "cash" in subtype_text)
        if looks_cash and has_dates and has_rate:
            found.append(value)
            return

        for key, nested in value.items():
            key_norm = str(key).lower()
            child_cash = in_cash_bucket or key_norm in {"cash_dividend", "cash_dividends"}
            walk(nested, in_cash_bucket=child_cash)

    walk(payload)
    return found


def build_dividend_events(
    *, api_key: str, secret_key: str, symbols: Iterable[str], start: date, end: date, output_path: str | Path
) -> list[CashDividend]:
    symbols = tuple(dict.fromkeys(_normalize_symbol(s) for s in symbols))
    if not symbols:
        raise ValueError("at least one dividend symbol is required")
    rows: list[CashDividend] = []
    # Query in modest symbol batches and paginate. Process-date search receives a 430-day
    # warmup so TTM yield is available at the requested research start.
    query_start = start - timedelta(days=430)
    for offset in range(0, len(symbols), 50):
        batch = symbols[offset : offset + 50]
        page_token: str | None = None
        while True:
            params = {
                "symbols": ",".join(batch),
                "types": "cash_dividend",
                "start": query_start.isoformat(),
                "end": end.isoformat(),
                "limit": "1000",
                "sort": "asc",
            }
            if page_token:
                params["page_token"] = page_token
            url = "https://data.alpaca.markets/v1/corporate-actions?" + urllib.parse.urlencode(params)
            payload = _http_json(url, api_key=api_key, secret_key=secret_key)
            for item in _extract_cash_dividends(payload):
                symbol = _normalize_symbol(str(item.get("symbol") or ""))
                ex_raw = item.get("ex_date") or item.get("exDate")
                pay_raw = item.get("payable_date") or item.get("pay_date") or item.get("payableDate")
                rate_raw = item.get("rate") or item.get("cash") or item.get("amount")
                if not ex_raw or not pay_raw or rate_raw in (None, ""):
                    continue
                try:
                    ex_date = date.fromisoformat(str(ex_raw)[:10])
                    payable_date = date.fromisoformat(str(pay_raw)[:10])
                    rate = Decimal(str(rate_raw))
                except (ValueError, InvalidOperation):
                    continue
                if rate <= 0 or payable_date < ex_date:
                    continue
                rows.append(
                    CashDividend(
                        symbol=symbol,
                        ex_date=ex_date,
                        payable_date=payable_date,
                        rate=rate,
                        source_id=str(item.get("id") or item.get("ca_id") or "") or None,
                        verified=True,
                    )
                )
            page_token = payload.get("next_page_token")
            if not page_token and isinstance(payload.get("data"), dict):
                page_token = payload["data"].get("next_page_token")
            if not page_token:
                break
    unique = {(r.symbol, r.ex_date, r.payable_date, r.rate): r for r in rows}
    result = sorted(unique.values(), key=lambda x: (x.ex_date, x.symbol, x.payable_date))
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=[*DIVIDEND_REQUIRED_COLUMNS, *DIVIDEND_OPTIONAL_COLUMNS])
        writer.writeheader()
        for event in result:
            writer.writerow({
                "symbol": event.symbol,
                "ex_date": event.ex_date.isoformat(),
                "payable_date": event.payable_date.isoformat(),
                "rate": str(event.rate),
                "source_id": event.source_id or "",
                "verified": "true" if event.verified else "false",
            })
    return result
