from __future__ import annotations

from datetime import date
from decimal import Decimal

import pandas as pd

from bot.backtest import BacktestSettings
from bot.dividend_data import CashDividend, load_dividend_events_csv, trailing_dividend_stats
from bot.strategies.common import indicators
from bot.strategies.dividend import DIVIDEND_QUALITY, dividend_signal
from bot.strategy_lab import DividendStrategySimulator


def rising_frame(periods=300, start="2024-01-02"):
    dates = pd.bdate_range(start, periods=periods).date
    closes = [80.0 + i * 0.08 for i in range(periods)]
    return pd.DataFrame(
        {
            "open": closes,
            "high": [c * 1.003 for c in closes],
            "low": [c * 0.997 for c in closes],
            "close": closes,
            "volume": [2_000_000.0] * periods,
        },
        index=dates,
    )


def test_dividend_csv_and_trailing_quality(tmp_path):
    path = tmp_path / "div.csv"
    path.write_text(
        "symbol,ex_date,payable_date,rate,source_id,verified\n"
        "AAA,2024-03-01,2024-03-15,1.0,a,true\n"
        "AAA,2024-06-01,2024-06-15,1.0,b,true\n"
        "AAA,2024-09-01,2024-09-15,1.0,c,true\n"
        "AAA,2024-12-01,2024-12-15,1.0,d,true\n",
        encoding="utf-8",
    )
    events = load_dividend_events_csv(path)
    stats = trailing_dividend_stats(events, symbol="AAA", as_of=date(2024, 12, 31), price=Decimal("100"))
    assert len(events) == 4
    assert stats["stable"] is True
    assert stats["cut"] is False
    assert 0.039 < stats["yield"] < 0.041


def test_dividend_quality_signal_requires_stable_3_to_7_pct_yield():
    frame = indicators(rising_frame())
    frame.attrs["symbol"] = "AAA"
    current = frame.index[-1]
    dates = list(frame.index)
    events = [
        CashDividend("AAA", dates[i], dates[min(i + 5, len(dates) - 1)], Decimal("1.1"))
        for i in (120, 170, 220, 270)
    ]
    signal = dividend_signal(DIVIDEND_QUALITY, frame, "GREEN", frame, events)
    assert signal is not None
    assert 0.03 <= signal.metadata["dividend_yield"] <= 0.07


def test_dividend_simulator_credits_cash_after_ex_date():
    frame = rising_frame(340, "2024-01-02")
    dates = list(frame.index)
    start = dates[250]
    end = dates[-1]
    # Four prior payments establish quality; a fifth dividend occurs after the strategy can enter.
    prior_indices = [80, 140, 190, 235]
    events = [
        CashDividend("AAA", dates[i], dates[min(i + 5, len(dates)-1)], Decimal("1.0"), verified=True)
        for i in prior_indices
    ]
    future_ex = dates[280]
    events.append(CashDividend("AAA", future_ex, dates[285], Decimal("1.0"), verified=True))
    settings = BacktestSettings(
        start=start,
        end=end,
        initial_capital=Decimal("100"),
        watchlist=("AAA",),
        max_daily_drawdown_pct=Decimal("1"),
        max_high_water_drawdown_pct=Decimal("1"),
    )
    bars = {"AAA": frame.copy(), "SPY": frame.copy()}
    result = DividendStrategySimulator(DIVIDEND_QUALITY, settings, bars, events).run()
    assert result.summary["dividend_income"] > 0
    assert result.summary["dividend_payments"] >= 1


def test_extract_cash_dividends_supports_symbol_keyed_response():
    from bot.dividend_data import _extract_cash_dividends

    payload = {
        "corporate_actions": {
            "cash_dividends": {
                "AAPL": [
                    {
                        "id": "d1",
                        "symbol": "AAPL",
                        "type": "cash_dividend",
                        "ex_date": "2025-02-10",
                        "payable_date": "2025-02-13",
                        "rate": "0.25",
                    }
                ]
            }
        },
        "next_page_token": None,
    }
    rows = _extract_cash_dividends(payload)
    assert len(rows) == 1
    assert rows[0]["symbol"] == "AAPL"


def test_extract_cash_dividends_supports_announcement_style_fields():
    from bot.dividend_data import _extract_cash_dividends

    payload = {
        "cash_dividends": [
            {
                "id": "d2",
                "symbol": "KO",
                "ca_type": "Dividend",
                "ca_sub_type": "cash",
                "ex_date": "2025-03-14",
                "payable_date": "2025-04-01",
                "cash": "0.51",
            }
        ]
    }
    rows = _extract_cash_dividends(payload)
    assert len(rows) == 1
    assert rows[0]["cash"] == "0.51"
