from __future__ import annotations

import argparse
import json
import os
import sys

import uvicorn

from bot.config import Config


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Phone-first adaptive Alpaca PAPER trading research app")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("web", help="Run the authenticated mobile dashboard")
    sub.add_parser("scan", help="Run one market scan")
    sub.add_parser("cycle", help="Run scan + outcome labeling + weekly challenger maintenance")
    sub.add_parser("status", help="Print PAPER account / safety status")
    sub.add_parser("label", help="Label due candidate outcomes")
    sub.add_parser("train", help="Train a challenger model if enough labeled observations exist")
    sub.add_parser("init-db", help="Create database tables and default safety settings")

    backtest = sub.add_parser("backtest", help="Run an isolated historical daily-bar backtest")
    backtest.add_argument("--years", type=int, help="Number of calendar years ending today")
    backtest.add_argument("--start", help="Inclusive start date in YYYY-MM-DD format")
    backtest.add_argument("--end", help="Inclusive end date in YYYY-MM-DD format")
    backtest.add_argument("--capital", default="100", help="Starting capital, default: 100")
    backtest.add_argument("--slippage", default="0.001", help="Adverse slippage, default: 0.001")

    compare = sub.add_parser("compare", help="Run the research-only multi-strategy comparison lab")
    compare.add_argument("--start", required=True, help="Inclusive start date in YYYY-MM-DD format")
    compare.add_argument("--end", required=True, help="Inclusive end date in YYYY-MM-DD format")
    compare.add_argument("--capital", default="100", help="Starting capital, default: 100")
    compare.add_argument("--slippage", default="0.001", help="Adverse slippage, default: 0.001")
    compare.add_argument("--holdout-start", required=True, help="Start date for untouched holdout evaluation")
    compare.add_argument(
        "--copy-signals",
        help="Optional strict copy-signal CSV; adds the eight research-only copy strategies",
    )
    compare.add_argument(
        "--legendary-signals",
        help="Optional delayed public 13F legendary-manager CSV; adds four disclosure-following strategies",
    )
    compare.add_argument(
        "--congress-signals",
        help="Optional strict historical congressional-disclosure CSV; adds congress-overlay strategies",
    )
    compare.add_argument(
        "--news-assessments",
        help="Optional strict historical news-veto assessment CSV; adds news-overlay strategies",
    )
    compare.add_argument(
        "--dividend-events",
        help="Optional historical cash-dividend CSV; adds four dividend-compounding strategies",
    )
    compare.add_argument(
        "--include-experimental",
        action="store_true",
        help="Also include post-hoc GREEN-only regime variants",
    )

    suite = sub.add_parser(
        "research-suite",
        help="Run all implemented price, regime, copy, congress, and news research strategies at once",
    )
    suite.add_argument("--start", required=True, help="Inclusive start date in YYYY-MM-DD format")
    suite.add_argument("--end", required=True, help="Inclusive end date in YYYY-MM-DD format")
    suite.add_argument("--holdout-start", required=True, help="Start date for descriptive validation split")
    suite.add_argument("--capital", default="100", help="Starting capital, default: 100")
    suite.add_argument(
        "--copy-signals",
        help="Optional true timestamped copy-alert CSV; omit when testing delayed 13F legendary-manager signals",
    )
    suite.add_argument(
        "--legendary-signals", required=True, help="Strict delayed public 13F legendary-manager CSV"
    )
    suite.add_argument("--congress-signals", required=True, help="Strict historical congressional-disclosure CSV")
    suite.add_argument("--news-assessments", required=True, help="Strict historical news-veto assessment CSV")
    suite.add_argument("--dividend-events", required=True, help="Strict historical cash-dividend event CSV")
    suite.add_argument(
        "--slippages",
        default="0.001,0.0025,0.005",
        help="Comma-separated all-strategy screening slippages",
    )

    legends = sub.add_parser(
        "build-legendary-signals",
        help="Build delayed public 13F signals for a fixed legendary-manager cohort",
    )
    legends.add_argument("--start", required=True, help="Inclusive research start date in YYYY-MM-DD format")
    legends.add_argument("--end", required=True, help="Inclusive research end date in YYYY-MM-DD format")
    legends.add_argument(
        "--output", default="data/legendary_manager_signals.csv", help="Output CSV path"
    )
    legends.add_argument(
        "--min-weight", type=float, default=0.01, help="Minimum disclosed portfolio weight, default: 0.01"
    )

    congress_builder = sub.add_parser(
        "build-congress-signals",
        help="Build delayed congressional disclosure signals from Quiver for a research universe",
    )
    congress_builder.add_argument("--start", required=True)
    congress_builder.add_argument("--end", required=True)
    congress_builder.add_argument("--output", default="data/congress_signals.csv")
    congress_builder.add_argument("--symbols", help="Comma-separated symbols; defaults to WATCHLIST")

    news_builder = sub.add_parser(
        "build-news-assessments",
        help="Freeze historical Alpaca-news veto assessments only on technical candidate dates",
    )
    news_builder.add_argument("--start", required=True)
    news_builder.add_argument("--end", required=True)
    news_builder.add_argument("--output", default="data/news_assessments.csv")
    news_builder.add_argument("--symbols", help="Comma-separated symbols; defaults to WATCHLIST")
    news_builder.add_argument("--max-assessments", type=int, help="Optional resumable cap for one run")

    dividend_builder = sub.add_parser(
        "build-dividend-events",
        help="Build historical Alpaca cash-dividend events for the research universe",
    )
    dividend_builder.add_argument("--start", required=True)
    dividend_builder.add_argument("--end", required=True)
    dividend_builder.add_argument("--output", default="data/dividend_events.csv")
    dividend_builder.add_argument("--symbols", help="Comma-separated symbols; defaults to WATCHLIST")

    build_all = sub.add_parser(
        "build-research-data",
        help="Build dividend, Congress, and resumable historical-news datasets in one command",
    )
    build_all.add_argument("--start", required=True)
    build_all.add_argument("--end", required=True)
    build_all.add_argument("--legendary-signals", default="data/legendary_manager_signals.csv")
    build_all.add_argument("--dividend-output", default="data/dividend_events.csv")
    build_all.add_argument("--congress-output", default="data/congress_signals.csv")
    build_all.add_argument("--news-output", default="data/news_assessments.csv")
    build_all.add_argument("--symbols", help="Comma-separated symbols; defaults to WATCHLIST")
    build_all.add_argument("--news-max-assessments", type=int, help="Optional resumable news batch cap")

    validate_data = sub.add_parser(
        "validate-research-data",
        help="Validate all historical research datasets before the all-strategy suite",
    )
    validate_data.add_argument("--legendary-signals", required=True)
    validate_data.add_argument("--congress-signals", required=True)
    validate_data.add_argument("--news-assessments", required=True)
    validate_data.add_argument("--dividend-events", required=True)
    validate_data.add_argument("--copy-signals")

    robustness = sub.add_parser(
        "robustness",
        help="Run research-only slippage, rolling-window, benchmark, and shadow-continuation stress tests",
    )
    robustness.add_argument("--start", required=True, help="Inclusive start date in YYYY-MM-DD format")
    robustness.add_argument("--end", required=True, help="Inclusive end date in YYYY-MM-DD format")
    robustness.add_argument("--holdout-start", required=True, help="Start date for untouched holdout evaluation")
    robustness.add_argument("--capital", default="100", help="Starting capital, default: 100")
    robustness.add_argument(
        "--strategies",
        default="ma_20_100,ma_50_200,donchian_55",
        help="Comma-separated research strategy keys",
    )
    robustness.add_argument(
        "--slippages",
        default="0,0.001,0.0015,0.002,0.0025,0.005",
        help="Comma-separated main-period slippage assumptions",
    )
    robustness.add_argument(
        "--window-slippages",
        default="0.001,0.0025",
        help="Comma-separated slippages for rolling/calendar windows",
    )
    robustness.add_argument(
        "--rolling-months",
        default="12,24",
        help="Comma-separated rolling window lengths in months",
    )
    robustness.add_argument(
        "--window-step-months",
        type=int,
        default=12,
        help="Months between rolling window starts, default: 12 (use 6 for denser rolling tests)",
    )

    flat = sub.add_parser("flatten", help="Cancel orders and close all PAPER positions")
    flat.add_argument("--confirm", required=True)

    promote = sub.add_parser("promote", help="Promote a challenger model to production ranking status")
    promote.add_argument("model_id", type=int)
    promote.add_argument("--confirm", required=True)
    return p


def main() -> int:
    args = parser().parse_args()
    try:
        cfg = Config.load()
        if args.command == "init-db":
            from bot.db import Database

            Database(cfg.database_url).init()
            print("Database initialized. Paper execution defaults to DISARMED.")
            return 0
        if args.command == "status":
            from bot.main import status

            print(json.dumps(status(cfg), indent=2, sort_keys=True))
            return 0
        if args.command == "scan":
            from bot.main import run_scan

            return run_scan(cfg)
        if args.command == "cycle":
            from bot.main import run_cycle

            print(json.dumps(run_cycle(cfg), indent=2, sort_keys=True))
            return 0
        if args.command == "label":
            from bot.main import label_outcomes

            print(json.dumps(label_outcomes(cfg), indent=2, sort_keys=True))
            return 0
        if args.command == "train":
            from bot.main import train_model

            print(json.dumps(train_model(cfg), indent=2, sort_keys=True))
            return 0
        if args.command == "backtest":
            from bot.backtest import run_backtest

            return run_backtest(
                cfg,
                years=args.years,
                start_text=args.start,
                end_text=args.end,
                capital=args.capital,
                slippage=args.slippage,
            )
        if args.command == "compare":
            from bot.strategy_lab import run_comparison

            return run_comparison(
                cfg,
                start_text=args.start,
                end_text=args.end,
                capital=args.capital,
                slippage=args.slippage,
                holdout_start_text=args.holdout_start,
                copy_signals_path=args.copy_signals,
                legendary_signals_path=args.legendary_signals,
                congress_signals_path=args.congress_signals,
                news_assessments_path=args.news_assessments,
                dividend_events_path=args.dividend_events,
                include_experimental=args.include_experimental,
            )
        if args.command == "research-suite":
            from bot.strategy_lab import run_research_suite

            return run_research_suite(
                cfg,
                start_text=args.start,
                end_text=args.end,
                holdout_start_text=args.holdout_start,
                capital=args.capital,
                copy_signals_path=args.copy_signals,
                legendary_signals_path=args.legendary_signals,
                congress_signals_path=args.congress_signals,
                news_assessments_path=args.news_assessments,
                dividend_events_path=args.dividend_events,
                slippages_text=args.slippages,
            )
        if args.command == "build-congress-signals":
            from bot.backtest import parse_date
            from bot.research_data_builder import build_congress_signals_quiver

            symbols = tuple(s.strip().upper() for s in args.symbols.split(",") if s.strip()) if args.symbols else cfg.watchlist
            count = build_congress_signals_quiver(
                symbols=symbols, start=parse_date(args.start), end=parse_date(args.end), output_path=args.output
            )
            print(f"Wrote {count} delayed congressional disclosure signals to {args.output}")
            print("Report date is the availability boundary; same-day use is excluded in research scoring.")
            return 0
        if args.command == "build-news-assessments":
            from bot.backtest import parse_date
            from bot.research_data_builder import build_news_assessments

            symbols = tuple(s.strip().upper() for s in args.symbols.split(",") if s.strip()) if args.symbols else cfg.watchlist
            count = build_news_assessments(
                cfg=cfg, start=parse_date(args.start), end=parse_date(args.end), symbols=symbols,
                output_path=args.output, max_assessments=args.max_assessments,
            )
            print(f"Historical news assessment cache now contains {count} rows at {args.output}")
            return 0
        if args.command == "build-dividend-events":
            from bot.backtest import parse_date
            from bot.dividend_data import build_dividend_events

            symbols = tuple(s.strip().upper() for s in args.symbols.split(",") if s.strip()) if args.symbols else cfg.watchlist
            events = build_dividend_events(
                api_key=cfg.alpaca_api_key, secret_key=cfg.alpaca_secret_key, symbols=symbols,
                start=parse_date(args.start), end=parse_date(args.end), output_path=args.output,
            )
            print(f"Wrote {len(events)} historical cash-dividend events to {args.output}")
            return 0
        if args.command == "build-research-data":
            from bot.backtest import parse_date
            from bot.dividend_data import build_dividend_events
            from bot.legendary_managers import load_manager_signals_csv
            from bot.research_data_builder import build_congress_signals_quiver, build_news_assessments

            start = parse_date(args.start)
            end = parse_date(args.end)
            symbols = tuple(s.strip().upper() for s in args.symbols.split(",") if s.strip()) if args.symbols else cfg.watchlist
            legendary_count = len(load_manager_signals_csv(args.legendary_signals))
            dividends = build_dividend_events(
                api_key=cfg.alpaca_api_key, secret_key=cfg.alpaca_secret_key, symbols=symbols,
                start=start, end=end, output_path=args.dividend_output,
            )
            congress_count = build_congress_signals_quiver(
                symbols=symbols, start=start, end=end, output_path=args.congress_output
            )
            news_count = build_news_assessments(
                cfg=cfg, start=start, end=end, symbols=symbols, output_path=args.news_output,
                max_assessments=args.news_max_assessments,
            )
            print(json.dumps({
                "legendary": legendary_count, "dividends": len(dividends),
                "congress": congress_count, "news_cache": news_count,
            }, indent=2, sort_keys=True))
            return 0
        if args.command == "validate-research-data":
            from bot.copy_signals import load_copy_signals_csv
            from bot.dividend_data import load_dividend_events_csv
            from bot.legendary_managers import load_manager_signals_csv
            from bot.research_signals import load_congress_signals_csv, load_news_assessments_csv

            payload = {
                "legendary": len(load_manager_signals_csv(args.legendary_signals)),
                "congress": len(load_congress_signals_csv(args.congress_signals)),
                "news": len(load_news_assessments_csv(args.news_assessments)),
                "dividends": len(load_dividend_events_csv(args.dividend_events)),
                "copy": len(load_copy_signals_csv(args.copy_signals)) if args.copy_signals else 0,
            }
            print(json.dumps(payload, indent=2, sort_keys=True))
            return 0
        if args.command == "build-legendary-signals":
            from bot.backtest import parse_date
            from bot.legendary_managers import build_legendary_manager_signals_from_env

            signals = build_legendary_manager_signals_from_env(
                start=parse_date(args.start),
                end=parse_date(args.end),
                output_path=args.output,
                min_portfolio_weight=args.min_weight,
            )
            print(f"Wrote {len(signals)} delayed public 13F signals to {args.output}")
            print("These are disclosure-following signals, not reconstructed manager execution prices.")
            return 0
        if args.command == "robustness":
            from bot.robustness_lab import run_robustness

            return run_robustness(
                cfg,
                start_text=args.start,
                end_text=args.end,
                holdout_start_text=args.holdout_start,
                capital=args.capital,
                strategies_text=args.strategies,
                slippages_text=args.slippages,
                window_slippages_text=args.window_slippages,
                rolling_months_text=args.rolling_months,
                window_step_months=args.window_step_months,
            )
        if args.command == "promote":
            from bot.main import promote_model

            ok = promote_model(cfg, args.model_id, args.confirm)
            print("promoted" if ok else "model_not_found")
            return 0 if ok else 2
        if args.command == "flatten":
            from bot.main import flatten

            return flatten(cfg, args.confirm)
        if args.command == "web":
            from bot.dashboard import create_app

            cfg.require_dashboard_security()
            port = int(os.getenv("PORT", "5000"))
            uvicorn.run(create_app(cfg), host="0.0.0.0", port=port, log_level="info")
            return 0
        return 2
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
