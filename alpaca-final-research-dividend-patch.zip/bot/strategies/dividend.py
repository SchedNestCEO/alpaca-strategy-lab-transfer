from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Iterable

import pandas as pd

from ..dividend_data import CashDividend, trailing_dividend_stats
from .breakout import donchian_55_signal
from .common import StrategySignal, current_row, stop_pct
from .trend import ma_20_100_signal

DIVIDEND_QUALITY = "dividend_quality"
DIVIDEND_TREND = "dividend_trend"
DIVIDEND_DONCHIAN = "dividend_donchian"
DIVIDEND_QUALITY_GREEN = "dividend_quality_green"
DIVIDEND_STRATEGY_KEYS = (
    DIVIDEND_QUALITY,
    DIVIDEND_TREND,
    DIVIDEND_DONCHIAN,
    DIVIDEND_QUALITY_GREEN,
)

MIN_YIELD = 0.03
MAX_YIELD = 0.07


def _quality_signal(history: pd.DataFrame, events: Iterable[CashDividend]) -> StrategySignal | None:
    prepared = current_row(history)
    if prepared is None:
        return None
    _, row = prepared
    current_date = history.index[-1]
    if not isinstance(current_date, date):
        return None
    price = Decimal(str(row["close"]))
    stats = trailing_dividend_stats(events, symbol=str(history.attrs.get("symbol", "")), as_of=current_date, price=price)
    if not stats["stable"] or stats["cut"]:
        return None
    div_yield = float(stats["yield"])
    if not (MIN_YIELD <= div_yield <= MAX_YIELD):
        return None
    if not (row["close"] > row["sma200"] and bool(row["sma200_rising"])):
        return None
    stop = stop_pct(row)
    if stop is None:
        return None
    score = 60.0 + min(20.0, (div_yield - MIN_YIELD) / (MAX_YIELD - MIN_YIELD) * 20.0)
    return StrategySignal(stop_pct=stop, score=score, metadata={"dividend_yield": div_yield})


def dividend_signal(
    key: str,
    history: pd.DataFrame,
    regime: str,
    spy_history: pd.DataFrame,
    events: Iterable[CashDividend],
) -> StrategySignal | None:
    if regime == "RED":
        return None
    base = _quality_signal(history, events)
    if base is None:
        return None
    if key == DIVIDEND_QUALITY_GREEN and regime != "GREEN":
        return None
    if key == DIVIDEND_TREND:
        trend = ma_20_100_signal(history, regime)
        if trend is None:
            return None
        return StrategySignal(
            stop_pct=trend.stop_pct,
            score=max(base.score, trend.score) + 5.0,
            metadata={**base.metadata, "adaptive_route": key},
        )
    if key == DIVIDEND_DONCHIAN:
        breakout = donchian_55_signal(history, regime)
        if breakout is None:
            return None
        return StrategySignal(
            stop_pct=breakout.stop_pct,
            score=max(base.score, breakout.score) + 5.0,
            metadata={**base.metadata, "adaptive_route": key},
        )
    return base


def dividend_quality_exit(history: pd.DataFrame, events: Iterable[CashDividend]) -> bool:
    prepared = current_row(history)
    if prepared is None:
        return False
    _, row = prepared
    current_date = history.index[-1]
    stats = trailing_dividend_stats(
        events,
        symbol=str(history.attrs.get("symbol", "")),
        as_of=current_date,
        price=Decimal(str(row["close"])),
    )
    return bool(stats["cut"] or row["close"] < row["sma200"])
