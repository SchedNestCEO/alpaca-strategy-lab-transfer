from __future__ import annotations

import csv
import json
import os
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import date, datetime, time as dt_time, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from typing import Iterable
from zoneinfo import ZoneInfo

from .backtest import fetch_historical_bars
from .config import Config
from .indicators import market_regime
from .research_signals import load_congress_signals_csv, load_news_assessments_csv
from .strategies.breakout import donchian_55_signal
from .strategies.common import indicators
from .strategies.trend import ma_20_100_signal, ma_50_200_signal

UTC = timezone.utc
ET = ZoneInfo("America/New_York")


def _request_json(url: str, *, headers: dict[str, str], retries: int = 4) -> object:
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=45) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            if exc.code == 429 and attempt < retries:
                retry_after = float(exc.headers.get("Retry-After", "2") or 2)
                time.sleep(max(1.0, retry_after))
                continue
            raise RuntimeError(f"HTTP {exc.code} from {url}") from exc
        except urllib.error.URLError as exc:
            if attempt < retries:
                time.sleep(1.5 * (attempt + 1))
                continue
            raise RuntimeError(f"Network error from {url}: {exc.reason}") from exc
    raise RuntimeError(f"request failed: {url}")


def _parse_range(raw: str) -> tuple[str, str]:
    cleaned = (raw or "").replace("$", "").replace(",", "").strip()
    if not cleaned:
        return "", ""
    parts = [p.strip() for p in cleaned.replace("–", "-").split("-")]
    if len(parts) == 2:
        return parts[0], parts[1]
    if cleaned.endswith("+"):
        return cleaned[:-1], ""
    return "", ""


def build_congress_signals_quiver(
    *,
    symbols: Iterable[str],
    start: date,
    end: date,
    output_path: str | Path,
    api_key: str | None = None,
) -> int:
    key = (api_key or os.getenv("QUIVER_API_KEY", "")).strip()
    if not key:
        raise ValueError("QUIVER_API_KEY is required to build congressional signals")
    rows: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str, str]] = set()
    headers = {"Authorization": f"Bearer {key}", "Accept": "application/json"}
    for symbol in dict.fromkeys(s.strip().upper() for s in symbols if s.strip()):
        url = f"https://api.quiverquant.com/beta/historical/congresstrading/{urllib.parse.quote(symbol)}"
        payload = _request_json(url, headers=headers)
        if not isinstance(payload, list):
            continue
        for item in payload:
            if not isinstance(item, dict):
                continue
            report = str(item.get("ReportDate") or "")[:10]
            tx = str(item.get("TransactionDate") or "")[:10]
            ticker = str(item.get("Ticker") or symbol).upper().strip()
            action = str(item.get("Transaction") or "").lower()
            if not report or not tx or not ticker:
                continue
            try:
                report_date = date.fromisoformat(report)
                tx_date = date.fromisoformat(tx)
            except ValueError:
                continue
            if report_date < start or report_date > end:
                continue
            if "purchase" in action or "buy" in action:
                side = "BUY"
            elif "sale" in action or "sell" in action:
                side = "SELL"
            else:
                continue
            member = str(item.get("Representative") or item.get("Senator") or item.get("Name") or "unknown").strip()
            house = str(item.get("House") or "").strip()
            member_id = (member + (f" [{house}]" if house else "")).strip()
            amount_low, amount_high = _parse_range(str(item.get("Range") or ""))
            # Provider exposes report date, not a precise public timestamp. Assign end-of-day UTC
            # and the scorer also excludes same-date disclosures, preventing same-day look-ahead.
            disclosure_time = datetime.combine(report_date, dt_time(23, 59, 59), tzinfo=UTC)
            transaction_time = datetime.combine(tx_date, dt_time(12, 0), tzinfo=UTC)
            source_id = f"quiver:{member}:{ticker}:{tx}:{report}:{side}"
            dedupe = (member_id, ticker, side, tx, report)
            if dedupe in seen:
                continue
            seen.add(dedupe)
            rows.append({
                "member_id": member_id,
                "symbol": ticker,
                "side": side,
                "transaction_time": transaction_time.isoformat(),
                "disclosure_time": disclosure_time.isoformat(),
                "amount_low": amount_low,
                "amount_high": amount_high,
                "source_id": source_id,
                "verified": "true",
            })
        time.sleep(0.05)
    rows.sort(key=lambda r: (r["disclosure_time"], r["member_id"], r["symbol"]))
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    fields = ["member_id", "symbol", "side", "transaction_time", "disclosure_time", "amount_low", "amount_high", "source_id", "verified"]
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    load_congress_signals_csv(target)
    return len(rows)


def _candidate_signal_dates(cfg: Config, *, start: date, end: date, symbols: Iterable[str]) -> set[tuple[str, date]]:
    bars = fetch_historical_bars(
        cfg.alpaca_api_key,
        cfg.alpaca_secret_key,
        symbols,
        start=start,
        end=end,
        feed_name=cfg.data_feed or "iex",
    )
    prepared = {symbol: indicators(frame) for symbol, frame in bars.items()}
    spy = prepared.get("SPY")
    if spy is None or spy.empty:
        raise ValueError("SPY bars are required to derive historical news candidate dates")
    candidates: set[tuple[str, date]] = set()
    for current_date in [d for d in spy.index if start <= d <= end]:
        spy_history = spy.loc[spy.index <= current_date]
        try:
            regime = market_regime(spy_history).regime
        except Exception:
            continue
        if regime == "RED":
            continue
        for symbol, frame in prepared.items():
            if symbol == "SPY" or current_date not in frame.index:
                continue
            history = frame.loc[frame.index <= current_date]
            try:
                if any(fn(history, regime) is not None for fn in (ma_20_100_signal, ma_50_200_signal, donchian_55_signal)):
                    candidates.add((symbol, current_date))
            except Exception:
                continue
    return candidates


def _fetch_news_headlines(cfg: Config, *, symbol: str, signal_date: date, lookback_days: int, limit: int) -> list[str]:
    close_et = datetime.combine(signal_date, dt_time(16, 0), tzinfo=ET)
    cutoff = close_et.astimezone(UTC)
    start = cutoff - timedelta(days=lookback_days)
    params = {
        "symbols": symbol,
        "start": start.isoformat().replace("+00:00", "Z"),
        "end": cutoff.isoformat().replace("+00:00", "Z"),
        "sort": "desc",
        "limit": str(min(50, max(limit, 1))),
        "include_content": "false",
    }
    url = "https://data.alpaca.markets/v1beta1/news?" + urllib.parse.urlencode(params)
    payload = _request_json(url, headers={
        "APCA-API-KEY-ID": cfg.alpaca_api_key,
        "APCA-API-SECRET-KEY": cfg.alpaca_secret_key,
        "Accept": "application/json",
    })
    if not isinstance(payload, dict):
        return []
    items = payload.get("news") or []
    headlines: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        headline = str(item.get("headline") or "").strip()
        if headline:
            headlines.append(headline)
        if len(headlines) >= limit:
            break
    return headlines


def build_news_assessments(
    *, cfg: Config, start: date, end: date, symbols: Iterable[str], output_path: str | Path, max_assessments: int | None = None
) -> int:
    if not cfg.openai_api_key:
        raise ValueError("OPENAI_API_KEY is required to build historical news assessments")
    target = Path(output_path)
    existing: dict[tuple[str, date], dict[str, str]] = {}
    if target.exists():
        try:
            for item in load_news_assessments_csv(target):
                existing[(item.symbol, item.signal_date)] = {
                    "symbol": item.symbol,
                    "signal_date": item.signal_date.isoformat(),
                    "assessment_time": item.assessment_time.isoformat(),
                    "verdict": item.verdict,
                    "reason": item.reason,
                    "headline_count": str(item.headline_count or 0),
                    "source_id": item.source_id or "alpaca_news",
                }
        except ValueError:
            existing = {}
    candidates = sorted(_candidate_signal_dates(cfg, start=start, end=end, symbols=symbols), key=lambda x: (x[1], x[0]))
    pending = [item for item in candidates if item not in existing]
    if max_assessments is not None:
        pending = pending[:max_assessments]
    from openai import OpenAI
    from .news_filter import NewsAssessment, NewsRiskFilter

    client = OpenAI(api_key=cfg.openai_api_key)
    for index, (symbol, signal_date) in enumerate(pending, start=1):
        headlines = _fetch_news_headlines(
            cfg,
            symbol=symbol,
            signal_date=signal_date,
            lookback_days=cfg.news_lookback_days,
            limit=cfg.news_headlines,
        )
        close_et = datetime.combine(signal_date, dt_time(16, 0), tzinfo=ET)
        assessment_time = close_et.astimezone(UTC)
        if not headlines:
            verdict = "RISKY"
            reason = "no_recent_headlines_fail_closed"
        else:
            numbered = "\n".join(f"{i + 1}. {h}" for i, h in enumerate(headlines))
            response = client.responses.parse(
                model=cfg.openai_model,
                instructions=NewsRiskFilter.SYSTEM_INSTRUCTIONS,
                input=f"Symbol: {symbol}\nHeadlines:\n{numbered}",
                text_format=NewsAssessment,
                store=False,
            )
            parsed = response.output_parsed
            verdict = parsed.verdict if parsed is not None else "RISKY"
            reason = "openai_structured_output" if parsed is not None else "openai_unparsed_fail_closed"
        existing[(symbol, signal_date)] = {
            "symbol": symbol,
            "signal_date": signal_date.isoformat(),
            "assessment_time": assessment_time.isoformat(),
            "verdict": verdict,
            "reason": reason,
            "headline_count": str(len(headlines)),
            "source_id": "alpaca_news",
        }
        if index % 25 == 0:
            _write_news(target, existing.values())
    _write_news(target, existing.values())
    load_news_assessments_csv(target)
    return len(existing)


def _write_news(path: Path, rows: Iterable[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["symbol", "signal_date", "assessment_time", "verdict", "reason", "headline_count", "source_id"]
    ordered = sorted(rows, key=lambda r: (r["signal_date"], r["symbol"]))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(ordered)
