from __future__ import annotations

from datetime import date

from bot.research_data_builder import build_congress_signals_quiver
from bot.research_signals import load_congress_signals_csv


def test_quiver_congress_builder_uses_report_date_not_transaction_date(monkeypatch, tmp_path):
    payload = [
        {
            "Representative": "Jane Doe",
            "ReportDate": "2025-02-10",
            "TransactionDate": "2025-01-20",
            "Ticker": "AAA",
            "Transaction": "Purchase",
            "Range": "$1,001 - $15,000",
            "House": "House",
        }
    ]
    monkeypatch.setattr("bot.research_data_builder._request_json", lambda *a, **k: payload)
    out = tmp_path / "congress.csv"
    count = build_congress_signals_quiver(
        symbols=("AAA",), start=date(2025, 1, 1), end=date(2025, 12, 31), output_path=out, api_key="x"
    )
    rows = load_congress_signals_csv(out)
    assert count == 1
    assert rows[0].transaction_time.date().isoformat() == "2025-01-20"
    assert rows[0].disclosure_time.date().isoformat() == "2025-02-10"
    assert rows[0].disclosure_time.hour == 23
