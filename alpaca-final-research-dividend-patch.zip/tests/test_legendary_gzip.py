from __future__ import annotations

import gzip

from bot import legendary_managers


class Headers(dict):
    def get(self, key, default=None):
        return super().get(key, default)


class Response:
    def __init__(self, payload):
        self.payload = payload
        self.headers = Headers({"Content-Encoding": "gzip"})
    def __enter__(self):
        return self
    def __exit__(self, *args):
        return False
    def read(self):
        return self.payload


def test_sec_request_decompresses_gzip(monkeypatch):
    compressed = gzip.compress(b'{"ok": true}')
    monkeypatch.setattr(legendary_managers.urllib.request, "urlopen", lambda *a, **k: Response(compressed))
    assert legendary_managers._json_request("https://example.test", user_agent="test x@example.com") == {"ok": True}
