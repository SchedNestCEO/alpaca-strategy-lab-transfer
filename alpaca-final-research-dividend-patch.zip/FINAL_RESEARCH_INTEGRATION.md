# Final Research Integration

This update completes the historical-data path for the current research suite and adds four dividend-compounding challengers.

## New data inputs

- `data/dividend_events.csv`: Alpaca cash-dividend corporate actions.
- `data/congress_signals.csv`: delayed congressional disclosures imported through Quiver, with report date as the public availability boundary.
- `data/news_assessments.csv`: frozen historical AI veto decisions built only from Alpaca news available at or before the strategy decision close.

## Dividend accounting boundary

Dividend strategies do not use dividend-adjusted prices. They use split-adjusted bars and explicit cash credits. A simulated position must already be held before the ex-date to earn the dividend. The credit becomes cash on the payable date or first trading session after it. This cash increases future risk capital only after it is actually credited.

## Fixed dividend challengers

- `DIVIDEND_QUALITY`
- `DIVIDEND_TREND`
- `DIVIDEND_DONCHIAN`
- `DIVIDEND_QUALITY_GREEN`

The quality gate uses a fixed 3%-7% trailing yield range, at least three trailing payments, a recent-cut veto, and a rising long-term trend. These thresholds are declared before historical results are inspected and should not be retuned to rescue a failed backtest.

## Safety

No broker module, order submission, live-trading switch, DRY_RUN behavior, or paper-only construction is modified by this patch.
