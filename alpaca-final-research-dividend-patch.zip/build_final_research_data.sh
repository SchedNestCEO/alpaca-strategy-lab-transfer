#!/bin/bash
set -e

python3 run.py build-research-data \
  --start 2021-08-18 \
  --end 2026-08-17 \
  --legendary-signals data/legendary_manager_signals.csv \
  --news-max-assessments "${NEWS_BATCH_SIZE:-100}"

python3 run.py validate-research-data \
  --legendary-signals data/legendary_manager_signals.csv \
  --congress-signals data/congress_signals.csv \
  --news-assessments data/news_assessments.csv \
  --dividend-events data/dividend_events.csv
