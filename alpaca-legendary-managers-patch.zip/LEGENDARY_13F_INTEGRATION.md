# Legendary Manager 13F Research Integration

This module follows **public 13F disclosures**, not private manager executions. It is research-only and does not modify the broker path.

## Fixed cohort

- Berkshire Hathaway / Buffett lineage — CIK `0001067983`
- Duquesne Family Office / Druckenmiller — CIK `0001536411`
- Soros Fund Management — CIK `0001029160`
- Appaloosa / Tepper — CIK `0001656456`
- Baupost / Klarman — CIK `0001061768`
- Pershing Square / Ackman — CIK `0001336528`

The cohort is fixed before backtesting. It is not selected by looking at the requested backtest results.

## No-lookahead boundary

A Form 13F reports quarter-end holdings, not the exact trade date or trade price. The builder therefore:

1. compares consecutive public quarter-end holdings;
2. infers only that a position was increased or reduced sometime between reports;
3. makes that information available at the **SEC filing acceptance timestamp**;
4. never invents a manager execution price;
5. enters the historical follower no earlier than the next session open;
6. ignores 13F-HR/A amendments in the first version rather than backdating later disclosures;
7. skips put/call rows and follows long disclosed holdings only.

CUSIPs are mapped to tickers through OpenFIGI v3 and cached locally.

## Builder

Set a declared SEC user-agent in Replit Secrets, for example a name/company plus a real contact email:

`SEC_USER_AGENT=Your Name your-email@example.com`

Optional:

`OPENFIGI_API_KEY=...`

Then run:

```bash
python3 run.py build-legendary-signals \
  --start 2021-08-18 \
  --end 2026-08-17 \
  --output data/legendary_manager_signals.csv \
  --min-weight 0.01
```

`--min-weight 0.01` keeps changes in positions representing at least 1% of the manager's disclosed 13F value. This is a fixed data-reduction rule, not a parameter optimized on returns.

## Strategy variants

- `legendary_13f_raw`: any qualifying disclosed increase.
- `legendary_13f_concentrated`: requires at least 2% disclosed portfolio weight.
- `legendary_13f_consensus`: requires at least two cohort managers to have publicly disclosed an increase in the same symbol for the same report period by the candidate filing time.
- `legendary_13f_green`: raw disclosure follower, but only when the existing SPY regime is GREEN.

All variants preserve the existing RED no-entry gate, ATR stop rejection, 0.5% planned-risk cap, 10% notional cap, daily-loss gate, cooldown, position limits, and 5% high-water halt.

## Interpretation

These are delayed-disclosure strategies. They should not be described as exact copies of Buffett, Druckenmiller, Soros, Tepper, Klarman, or Ackman's private trades. Entity filings may reflect teams, multiple decision-makers, confidential-treatment effects, and transactions that happened weeks before disclosure.
