from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable

import pandas as pd

from ..legendary_managers import ManagerDisclosureSignal, manager_consensus_count_at
from .common import current_row

LEGENDARY_13F_RAW = "legendary_13f_raw"
LEGENDARY_13F_CONCENTRATED = "legendary_13f_concentrated"
LEGENDARY_13F_CONSENSUS = "legendary_13f_consensus"
LEGENDARY_13F_GREEN = "legendary_13f_green"

LEGENDARY_STRATEGY_KEYS = (
    LEGENDARY_13F_RAW,
    LEGENDARY_13F_CONCENTRATED,
    LEGENDARY_13F_CONSENSUS,
    LEGENDARY_13F_GREEN,
)


@dataclass(frozen=True)
class LegendaryPolicy:
    concentrated_min_weight: float = 0.02
    consensus_min_managers: int = 2


DEFAULT_LEGENDARY_POLICY = LegendaryPolicy()


@dataclass(frozen=True)
class LegendaryDecision:
    accepted: bool
    score: float
    reason: str
    stop_pct: Decimal | None
    consensus_count: int


def evaluate_legendary_signal(
    strategy_key: str,
    candidate: ManagerDisclosureSignal,
    *,
    all_signals: Iterable[ManagerDisclosureSignal],
    history: pd.DataFrame,
    regime: str,
    settings,
    policy: LegendaryPolicy = DEFAULT_LEGENDARY_POLICY,
) -> LegendaryDecision:
    if candidate.side != "BUY" or not candidate.verified:
        return LegendaryDecision(False, 0.0, "not_verified_buy", None, 0)
    if regime == "RED":
        return LegendaryDecision(False, 0.0, "red_regime", None, 0)
    prepared = current_row(history)
    if prepared is None:
        return LegendaryDecision(False, 0.0, "insufficient_history", None, 0)
    _, row = prepared
    atr_pct = Decimal(str(float(row["atr14"] / row["close"])))
    dynamic_stop = max(settings.min_stop_pct, settings.atr_stop_multiple * atr_pct)
    if dynamic_stop > settings.max_stop_pct:
        return LegendaryDecision(False, 0.0, "stop_rejected", None, 0)

    consensus = manager_consensus_count_at(candidate, all_signals)
    if strategy_key == LEGENDARY_13F_RAW:
        accepted, reason = True, "public_13f_increase"
    elif strategy_key == LEGENDARY_13F_CONCENTRATED:
        accepted = candidate.portfolio_weight >= policy.concentrated_min_weight
        reason = "concentrated"
    elif strategy_key == LEGENDARY_13F_CONSENSUS:
        accepted = consensus >= policy.consensus_min_managers
        reason = "consensus"
    elif strategy_key == LEGENDARY_13F_GREEN:
        accepted = regime == "GREEN"
        reason = "green_only"
    else:
        raise ValueError(f"Unknown legendary strategy {strategy_key!r}")

    score = 0.0
    if accepted:
        score = 50.0 + min(35.0, candidate.portfolio_weight * 500.0) + min(15.0, consensus * 5.0)
        if candidate.change_pct is not None and candidate.change_pct > 0:
            score += min(10.0, candidate.change_pct * 10.0)
    return LegendaryDecision(
        accepted=accepted,
        score=score,
        reason=reason if accepted else f"{reason}_rejected",
        stop_pct=dynamic_stop if accepted else None,
        consensus_count=consensus,
    )
