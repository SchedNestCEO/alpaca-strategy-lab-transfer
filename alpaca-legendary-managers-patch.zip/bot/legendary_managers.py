from __future__ import annotations

import csv
import json
import os
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Iterable
from zoneinfo import ZoneInfo

UTC = timezone.utc
NY = ZoneInfo("America/New_York")

LEGENDARY_MANAGERS: tuple[dict[str, str], ...] = (
    {
        "manager_id": "berkshire",
        "manager_label": "Berkshire Hathaway / Buffett",
        "cik": "0001067983",
    },
    {
        "manager_id": "duquesne",
        "manager_label": "Duquesne Family Office / Druckenmiller",
        "cik": "0001536411",
    },
    {
        "manager_id": "soros",
        "manager_label": "Soros Fund Management",
        "cik": "0001029160",
    },
    {
        "manager_id": "appaloosa",
        "manager_label": "Appaloosa / Tepper",
        "cik": "0001656456",
    },
    {
        "manager_id": "baupost",
        "manager_label": "Baupost / Klarman",
        "cik": "0001061768",
    },
    {
        "manager_id": "pershing",
        "manager_label": "Pershing Square / Ackman",
        "cik": "0001336528",
    },
)

MANAGER_REQUIRED_COLUMNS = (
    "manager_id",
    "manager_label",
    "symbol",
    "side",
    "report_period",
    "filing_time",
    "shares",
    "prior_shares",
    "change_pct",
    "portfolio_weight",
    "source_accession",
    "verified",
)
MANAGER_ALLOWED_COLUMNS = frozenset(MANAGER_REQUIRED_COLUMNS)


@dataclass(frozen=True)
class ManagerDisclosureSignal:
    manager_id: str
    manager_label: str
    symbol: str
    side: str
    report_period: date
    filing_time: datetime
    shares: Decimal
    prior_shares: Decimal
    change_pct: float | None
    portfolio_weight: float
    source_accession: str
    verified: bool
    row_number: int | None = None

    @property
    def identity(self) -> tuple[str, str, str, str]:
        return (
            self.manager_id,
            self.symbol,
            self.report_period.isoformat(),
            self.source_accession,
        )


@dataclass(frozen=True)
class _Filing:
    manager_id: str
    manager_label: str
    cik: str
    accession: str
    report_period: date
    filing_time: datetime


@dataclass(frozen=True)
class _Holding:
    cusip: str
    issuer: str
    shares: Decimal
    value: Decimal


def _parse_bool(raw: str, *, row_number: int) -> bool:
    value = raw.strip().lower()
    if value in {"1", "true", "yes", "y"}:
        return True
    if value in {"0", "false", "no", "n"}:
        return False
    raise ValueError(f"row {row_number}: verified must be true/false")


def _parse_decimal(raw: str, *, field: str, row_number: int) -> Decimal:
    try:
        value = Decimal(raw.strip())
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"row {row_number}: {field} must be a decimal number") from exc
    if not value.is_finite() or value < 0:
        raise ValueError(f"row {row_number}: {field} must be non-negative")
    return value


def _parse_optional_float(raw: str, *, field: str, row_number: int) -> float | None:
    value = raw.strip()
    if not value:
        return None
    try:
        parsed = float(value)
    except ValueError as exc:
        raise ValueError(f"row {row_number}: {field} must be numeric") from exc
    if not (float("-inf") < parsed < float("inf")):
        raise ValueError(f"row {row_number}: {field} must be finite")
    return parsed


def _parse_timestamp(raw: str, *, field: str, row_number: int) -> datetime:
    value = raw.strip()
    if value.endswith("Z"):
        value = value[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"row {row_number}: {field} must be ISO-8601") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"row {row_number}: {field} must be timezone-aware")
    return parsed.astimezone(UTC)


def load_manager_signals_csv(path: str | Path) -> list[ManagerDisclosureSignal]:
    source = Path(path)
    if not source.exists() or not source.is_file():
        raise ValueError(f"legendary-manager CSV does not exist: {source}")
    with source.open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fieldnames = tuple(reader.fieldnames or ())
        missing = [column for column in MANAGER_REQUIRED_COLUMNS if column not in fieldnames]
        if missing:
            raise ValueError(f"legendary-manager CSV missing required columns: {', '.join(missing)}")
        unknown = [column for column in fieldnames if column not in MANAGER_ALLOWED_COLUMNS]
        if unknown:
            raise ValueError(f"legendary-manager CSV has unknown columns: {', '.join(unknown)}")
        result: list[ManagerDisclosureSignal] = []
        seen: set[tuple[str, str, str, str, str]] = set()
        for row_number, row in enumerate(reader, start=2):
            manager_id = (row.get("manager_id") or "").strip()
            manager_label = (row.get("manager_label") or "").strip()
            symbol = (row.get("symbol") or "").strip().upper()
            side = (row.get("side") or "").strip().upper()
            if not manager_id or not manager_label:
                raise ValueError(f"row {row_number}: manager_id and manager_label are required")
            if not symbol or not symbol.replace(".", "").replace("-", "").isalnum():
                raise ValueError(f"row {row_number}: symbol is invalid")
            if side not in {"BUY", "SELL"}:
                raise ValueError(f"row {row_number}: side must be BUY or SELL")
            try:
                report_period = date.fromisoformat((row.get("report_period") or "").strip())
            except ValueError as exc:
                raise ValueError(f"row {row_number}: report_period must be YYYY-MM-DD") from exc
            filing_time = _parse_timestamp(row.get("filing_time") or "", field="filing_time", row_number=row_number)
            if filing_time.date() < report_period:
                raise ValueError(f"row {row_number}: filing_time cannot precede report_period")
            shares = _parse_decimal(row.get("shares") or "", field="shares", row_number=row_number)
            prior_shares = _parse_decimal(row.get("prior_shares") or "", field="prior_shares", row_number=row_number)
            change_pct = _parse_optional_float(row.get("change_pct") or "", field="change_pct", row_number=row_number)
            portfolio_weight = _parse_optional_float(
                row.get("portfolio_weight") or "", field="portfolio_weight", row_number=row_number
            )
            if portfolio_weight is None or not (0 <= portfolio_weight <= 1):
                raise ValueError(f"row {row_number}: portfolio_weight must be between 0 and 1")
            source_accession = (row.get("source_accession") or "").strip()
            if not source_accession:
                raise ValueError(f"row {row_number}: source_accession is required")
            verified = _parse_bool(row.get("verified") or "", row_number=row_number)
            key = (manager_id, symbol, side, report_period.isoformat(), source_accession)
            if key in seen:
                raise ValueError(f"row {row_number}: duplicate legendary-manager signal")
            seen.add(key)
            result.append(
                ManagerDisclosureSignal(
                    manager_id=manager_id,
                    manager_label=manager_label,
                    symbol=symbol,
                    side=side,
                    report_period=report_period,
                    filing_time=filing_time,
                    shares=shares,
                    prior_shares=prior_shares,
                    change_pct=change_pct,
                    portfolio_weight=portfolio_weight,
                    source_accession=source_accession,
                    verified=verified,
                    row_number=row_number,
                )
            )
    result.sort(key=lambda item: (item.filing_time, item.manager_id, item.symbol, item.side))
    return result


def manager_signal_symbols(signals: Iterable[ManagerDisclosureSignal]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(signal.symbol for signal in signals))


def manager_consensus_count_at(
    candidate: ManagerDisclosureSignal,
    signals: Iterable[ManagerDisclosureSignal],
) -> int:
    managers = {
        item.manager_id
        for item in signals
        if item.symbol == candidate.symbol
        and item.side == "BUY"
        and item.verified
        and item.report_period == candidate.report_period
        and item.filing_time <= candidate.filing_time
    }
    return len(managers)


def _request(url: str, *, user_agent: str, data: bytes | None = None, headers: dict[str, str] | None = None) -> bytes:
    merged = {
        "User-Agent": user_agent,
        "Accept-Encoding": "gzip, deflate",
    }
    if headers:
        merged.update(headers)
    request = urllib.request.Request(url, data=data, headers=merged, method="POST" if data is not None else "GET")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"HTTP {exc.code} from {url}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error fetching {url}: {exc.reason}") from exc


def _json_request(url: str, *, user_agent: str) -> dict:
    return json.loads(_request(url, user_agent=user_agent).decode("utf-8"))


def _parse_edgar_time(raw: str, fallback_date: str) -> datetime:
    value = (raw or "").strip()
    if value:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(value)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=NY)
            return parsed.astimezone(UTC)
        except ValueError:
            pass
    return datetime.fromisoformat(fallback_date + "T17:30:00").replace(tzinfo=NY).astimezone(UTC)


def _recent_rows(payload: dict) -> list[dict[str, str]]:
    recent = payload.get("filings", {}).get("recent", {})
    keys = [key for key, value in recent.items() if isinstance(value, list)]
    if not keys:
        return []
    count = max((len(recent[key]) for key in keys), default=0)
    rows: list[dict[str, str]] = []
    for idx in range(count):
        row = {key: (recent[key][idx] if idx < len(recent[key]) else "") for key in keys}
        rows.append(row)
    return rows


def _manager_filings(manager: dict[str, str], *, start: date, end: date, user_agent: str) -> list[_Filing]:
    cik = manager["cik"]
    payload = _json_request(f"https://data.sec.gov/submissions/CIK{cik}.json", user_agent=user_agent)
    rows = _recent_rows(payload)
    for old in payload.get("filings", {}).get("files", []) or []:
        name = old.get("name")
        if not name:
            continue
        old_payload = _json_request(f"https://data.sec.gov/submissions/{name}", user_agent=user_agent)
        rows.extend(_recent_rows({"filings": {"recent": old_payload}}) if "accessionNumber" in old_payload else [])
    filings: list[_Filing] = []
    for row in rows:
        if row.get("form") != "13F-HR":
            continue
        report_raw = row.get("reportDate") or ""
        filing_raw = row.get("filingDate") or ""
        accession = row.get("accessionNumber") or ""
        if not report_raw or not filing_raw or not accession:
            continue
        try:
            report_period = date.fromisoformat(report_raw)
            filing_date = date.fromisoformat(filing_raw)
        except ValueError:
            continue
        # Include one pre-start report so the first in-range quarter can be differenced.
        if report_period > end or filing_date < date(start.year - 1, 1, 1):
            continue
        filings.append(
            _Filing(
                manager_id=manager["manager_id"],
                manager_label=manager["manager_label"],
                cik=cik,
                accession=accession,
                report_period=report_period,
                filing_time=_parse_edgar_time(row.get("acceptanceDateTime") or "", filing_raw),
            )
        )
    dedup: dict[date, _Filing] = {}
    for filing in sorted(filings, key=lambda item: (item.report_period, item.filing_time)):
        dedup.setdefault(filing.report_period, filing)
    return sorted(dedup.values(), key=lambda item: (item.report_period, item.filing_time))


def _local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _child_text(parent: ET.Element, name: str) -> str:
    for child in parent.iter():
        if _local_name(child.tag) == name:
            return (child.text or "").strip()
    return ""


def _parse_information_table(xml_bytes: bytes) -> list[_Holding]:
    root = ET.fromstring(xml_bytes)
    holdings: list[_Holding] = []
    for node in root.iter():
        if _local_name(node.tag) != "infoTable":
            continue
        if _child_text(node, "putCall"):
            continue
        cusip = _child_text(node, "cusip").replace(" ", "").upper()
        issuer = _child_text(node, "nameOfIssuer")
        shares_raw = _child_text(node, "sshPrnamt")
        value_raw = _child_text(node, "value")
        if not cusip or not shares_raw or not value_raw:
            continue
        try:
            shares = Decimal(shares_raw.replace(",", ""))
            value = Decimal(value_raw.replace(",", ""))
        except InvalidOperation:
            continue
        if shares < 0 or value < 0:
            continue
        holdings.append(_Holding(cusip=cusip, issuer=issuer, shares=shares, value=value))
    return holdings


def _filing_holdings(filing: _Filing, *, user_agent: str) -> list[_Holding]:
    cik_int = str(int(filing.cik))
    accession_dir = filing.accession.replace("-", "")
    base = f"https://www.sec.gov/Archives/edgar/data/{cik_int}/{accession_dir}"
    index = _json_request(f"{base}/index.json", user_agent=user_agent)
    items = index.get("directory", {}).get("item", []) or []
    xml_names = [item.get("name") for item in items if str(item.get("name", "")).lower().endswith(".xml")]
    xml_names = [name for name in xml_names if name and name.lower() != "primary_doc.xml"]
    for name in xml_names:
        payload = _request(f"{base}/{name}", user_agent=user_agent)
        try:
            holdings = _parse_information_table(payload)
        except ET.ParseError:
            continue
        if holdings:
            return holdings
    raise RuntimeError(f"Could not find 13F information table for {filing.accession}")


def _openfigi_map(cusips: list[str], *, api_key: str | None, user_agent: str) -> dict[str, str]:
    result: dict[str, str] = {}
    if not cusips:
        return result
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["X-OPENFIGI-APIKEY"] = api_key
    batch_size = 10
    for start in range(0, len(cusips), batch_size):
        batch = cusips[start : start + batch_size]
        body = json.dumps([{"idType": "ID_CUSIP", "idValue": value} for value in batch]).encode("utf-8")
        payload = json.loads(
            _request(
                "https://api.openfigi.com/v3/mapping",
                user_agent=user_agent,
                data=body,
                headers=headers,
            ).decode("utf-8")
        )
        for cusip, response in zip(batch, payload):
            candidates = response.get("data") or []
            chosen = None
            for candidate in candidates:
                ticker = (candidate.get("ticker") or "").strip().upper()
                if ticker and candidate.get("marketSector") == "Equity":
                    chosen = ticker
                    break
            if chosen:
                result[cusip] = chosen
        time.sleep(0.35 if api_key else 0.75)
    return result


def _load_mapping_cache(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}
    return {str(key): str(value) for key, value in payload.items() if key and value}


def _save_mapping_cache(path: Path, mapping: dict[str, str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(sorted(mapping.items())), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def build_legendary_manager_signals(
    *,
    start: date,
    end: date,
    output_path: str | Path,
    sec_user_agent: str,
    openfigi_api_key: str | None = None,
    min_portfolio_weight: float = 0.01,
    managers: Iterable[dict[str, str]] = LEGENDARY_MANAGERS,
) -> list[ManagerDisclosureSignal]:
    """Build conservative delayed-following signals from public SEC 13F disclosures.

    This does NOT reconstruct the manager's actual trade time or execution price. It only
    compares quarter-end holdings and makes a signal available at the filing acceptance
    time. Research replay must enter no earlier than the following session open.
    """
    if start >= end:
        raise ValueError("start must be before end")
    if not sec_user_agent.strip() or " " not in sec_user_agent.strip() or "@" not in sec_user_agent:
        raise ValueError("SEC user agent should identify a person/company and contact email")
    if not (0 <= min_portfolio_weight < 1):
        raise ValueError("min_portfolio_weight must be between 0 and 1")

    output = Path(output_path)
    cache_path = output.parent / "openfigi_cusip_cache.json"
    mapping = _load_mapping_cache(cache_path)

    filing_holdings: list[tuple[_Filing, list[_Holding]]] = []
    all_cusips: set[str] = set()
    for manager in managers:
        filings = _manager_filings(manager, start=start, end=end, user_agent=sec_user_agent)
        for filing in filings:
            holdings = _filing_holdings(filing, user_agent=sec_user_agent)
            filing_holdings.append((filing, holdings))
            all_cusips.update(item.cusip for item in holdings)
            time.sleep(0.12)

    missing = sorted(all_cusips - set(mapping))
    if missing:
        mapping.update(_openfigi_map(missing, api_key=openfigi_api_key, user_agent=sec_user_agent))
        _save_mapping_cache(cache_path, mapping)

    by_manager: dict[str, list[tuple[_Filing, dict[str, tuple[Decimal, Decimal]]]]] = {}
    for filing, holdings in filing_holdings:
        total_value = sum((item.value for item in holdings), Decimal("0"))
        aggregated: dict[str, tuple[Decimal, Decimal]] = {}
        for item in holdings:
            symbol = mapping.get(item.cusip)
            if not symbol:
                continue
            shares, value = aggregated.get(symbol, (Decimal("0"), Decimal("0")))
            aggregated[symbol] = (shares + item.shares, value + item.value)
        by_manager.setdefault(filing.manager_id, []).append((filing, aggregated))

    signals: list[ManagerDisclosureSignal] = []
    for manager_id, snapshots in by_manager.items():
        snapshots.sort(key=lambda item: (item[0].report_period, item[0].filing_time))
        previous: dict[str, tuple[Decimal, Decimal]] | None = None
        for filing, current in snapshots:
            if previous is None:
                previous = current
                continue
            total_value = sum((value for _, value in current.values()), Decimal("0"))
            prior_total = sum((value for _, value in previous.values()), Decimal("0"))
            symbols = set(previous) | set(current)
            for symbol in symbols:
                prior_shares, prior_value = previous.get(symbol, (Decimal("0"), Decimal("0")))
                shares, value = current.get(symbol, (Decimal("0"), Decimal("0")))
                if shares == prior_shares:
                    continue
                side = "BUY" if shares > prior_shares else "SELL"
                weight_base = total_value if side == "BUY" else prior_total
                weight_value = value if side == "BUY" else prior_value
                weight = float(weight_value / weight_base) if weight_base > 0 else 0.0
                if weight < min_portfolio_weight:
                    continue
                change_pct = None
                if prior_shares > 0:
                    change_pct = float((shares - prior_shares) / prior_shares)
                elif shares > 0:
                    change_pct = 1.0
                if filing.filing_time.date() < start or filing.filing_time.date() > end:
                    continue
                signals.append(
                    ManagerDisclosureSignal(
                        manager_id=manager_id,
                        manager_label=filing.manager_label,
                        symbol=symbol,
                        side=side,
                        report_period=filing.report_period,
                        filing_time=filing.filing_time,
                        shares=shares,
                        prior_shares=prior_shares,
                        change_pct=change_pct,
                        portfolio_weight=weight,
                        source_accession=filing.accession,
                        verified=True,
                    )
                )
            previous = current

    signals.sort(key=lambda item: (item.filing_time, item.manager_id, item.symbol, item.side))
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(MANAGER_REQUIRED_COLUMNS))
        writer.writeheader()
        for signal in signals:
            writer.writerow(
                {
                    "manager_id": signal.manager_id,
                    "manager_label": signal.manager_label,
                    "symbol": signal.symbol,
                    "side": signal.side,
                    "report_period": signal.report_period.isoformat(),
                    "filing_time": signal.filing_time.astimezone(UTC).isoformat(),
                    "shares": str(signal.shares),
                    "prior_shares": str(signal.prior_shares),
                    "change_pct": "" if signal.change_pct is None else f"{signal.change_pct:.10f}",
                    "portfolio_weight": f"{signal.portfolio_weight:.10f}",
                    "source_accession": signal.source_accession,
                    "verified": "true",
                }
            )
    return signals


def build_legendary_manager_signals_from_env(
    *,
    start: date,
    end: date,
    output_path: str | Path,
    min_portfolio_weight: float = 0.01,
) -> list[ManagerDisclosureSignal]:
    return build_legendary_manager_signals(
        start=start,
        end=end,
        output_path=output_path,
        sec_user_agent=os.getenv("SEC_USER_AGENT", ""),
        openfigi_api_key=os.getenv("OPENFIGI_API_KEY", "").strip() or None,
        min_portfolio_weight=min_portfolio_weight,
    )
